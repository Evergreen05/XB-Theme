<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <script>
        window.EZ_THEME_SETTINGS = {!! json_encode($theme_config ?? [], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) !!};
        window.__THEME_ROOT__ = '/theme/{{ $theme }}';
    </script>
    <script>
        (function(){var f=document.querySelector('link[rel~="icon"]');var u={!! json_encode($theme_config['ez_logo_url'] ?? '', JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) !!};if(f&&u){f.href=u;}})();
    </script>
    <meta charset="UTF-8">
    <meta name="description" content="{{ $description }}" >
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="icon" href="/theme/{{ $theme }}/images/logo.png">
    <title>{{ $title }}</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script src="/theme/{{ $theme }}/061.ogegl4o4.js"></script>
    <style>
        @media (min-width: 769px) {
            html, body, div, main, section, article, aside, nav {
                scrollbar-width: none !important;
                -ms-overflow-style: none !important;
            }

            ::-webkit-scrollbar, ::-webkit-scrollbar-button, ::-webkit-scrollbar-track, ::-webkit-scrollbar-track-piece, ::-webkit-scrollbar-thumb, ::-webkit-scrollbar-corner, ::-webkit-resizer {
                display: none !important;
                width: 0 !important;
                height: 0 !important;
                background: transparent !important;
            }
        }

        html, body {
            width: 100%;
            height: 100%;
        }

        @media (min-width: 769px) {
            * {
                scrollbar-width: none !important;
                -ms-overflow-style: none !important;
            }
        }

        html, body {
            margin: 0;
            padding: 0;
            width: 100%;
            height: 100%;
            overflow-x: hidden;
        }

        #app {
            width: 100%;
            height: 100%;
        }

        html.preloader-active, body.preloader-active {
            overflow: hidden !important;
        }
    </style>
    <style>
        .app-version {
            position: fixed;
            left: 6px;
            bottom: 4px;
            font-size: 9px;
            color: rgba(0, 0, 0, 0.35);
            user-select: none;
            pointer-events: none;
            z-index: 5;
        }
    </style>
  <script type="module" crossorigin src="/theme/{{ $theme }}/static/index-CFPsXE4Y.js"></script>
  <link rel="modulepreload" crossorigin href="/theme/{{ $theme }}/static/vendor-CZc0_yAv.js">
  <link rel="stylesheet" crossorigin href="/theme/{{ $theme }}/static/vendor-BgDCIyLK.css">
</head>
<body>
<div id="app"></div>
<!-- 隐藏版本号角标
<div class="app-version">v0.4.0</div>
-->
    {!! ($theme_config['ez_custom_html'] ?? ($theme_config['EZ_CUSTOM_HTML'] ?? '')) !!}
</body>
</html>
